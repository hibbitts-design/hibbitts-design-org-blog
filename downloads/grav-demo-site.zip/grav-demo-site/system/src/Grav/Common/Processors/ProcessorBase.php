<?php
namespace Grav\Common\Processors;

class ProcessorBase {

  	public function __construct($container) {
    	$this->container = $container;
  	}

}
