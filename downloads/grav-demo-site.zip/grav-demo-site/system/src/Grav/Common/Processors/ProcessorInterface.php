<?php
namespace Grav\Common\Processors;

interface ProcessorInterface {
  	public function process();
}
