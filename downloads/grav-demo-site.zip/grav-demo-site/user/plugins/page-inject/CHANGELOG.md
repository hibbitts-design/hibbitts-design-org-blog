# v1.1.1
## 10/21/2015

1. [](#new)
    * Added `active` config option to enable/disable site-wide
1. [](#bugfix)
    * Fixed issue with plugin not processing reliably with cache-enabled

# v1.1.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.0.0
## 06/18/2015

1. [](#new)
    * ChangeLog started...
