# v1.3.1
## 09/23/2016

1. [](#improved)
    * Use common language strings
    * Set active by default

# v1.3.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.2.0
## 06/16/2015

1. [](#improved)
    * Updated to featherlight 1.3.2
    * Added Gallery support

# v1.1.0
## 03/24/2015

1. [](#improved)
    * Updated to featherlight 1.2.3
    * Added 'root' option to configure where featherlight is added
    * Added reference for to load jQuery if needed

# v1.0.3
## 02/19/2015

1. [](#improved)
    * README improvements

# v1.0.2
## 11/30/2014

1. [](#new)
    * ChangeLog started...
