---
title: DaringFireball Style Link
date: 13:34 07/05/2014
link: http://getgrav.org
taxonomy:
    category: blog
    tag: [journal, text]
---

> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ultricies tristique nulla et mattis. Phasellus id massa eget nisl congue blandit sit amet id ligula. Praesent et nulla eu augue tempus sagittis. Mauris faucibus nibh et nibh cursus in vestibulum sapien egestas. Curabitur ut lectus tortor. Sed ipsum eros, egestas ut eleifend non, elementum vitae eros.
> -- <cite> Ronald Wade</cite>
