---
title: CC-BY-SA
---

**CC-BY-SA**  
Creative Commons Attribution-Share Alike license. OER licensed CC-BY-SA may be modified and used commercially, provided credit is given to the author and it is shared in the same manner. This license is somewhat similar to the GFDL.
