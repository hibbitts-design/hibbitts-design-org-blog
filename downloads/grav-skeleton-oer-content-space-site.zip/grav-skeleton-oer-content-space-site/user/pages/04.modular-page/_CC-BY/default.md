---
title: CC-BY
---

**CC-BY**  
Creative Commons Attribution license. OER licensed CC-BY can be modified, used commercially and may or may not be shared in the same manner, provided credit is given to the author. 
