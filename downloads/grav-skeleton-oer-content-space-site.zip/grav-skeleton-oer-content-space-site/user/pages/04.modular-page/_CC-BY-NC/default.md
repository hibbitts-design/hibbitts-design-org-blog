---
title: CC-BY-NC
---
**CC-BY-NC**  
Creative Commons Attribution-Noncommercial license. OER licensed CC-BY-NC can be modified and may or may not be shared in the same manner, but credit must be given to the author and it cannot be used commercially.   
