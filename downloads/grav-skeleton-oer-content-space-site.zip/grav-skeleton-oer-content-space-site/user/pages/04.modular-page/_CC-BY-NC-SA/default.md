---
title: CC-BY-NC-SA
---

**CC-BY-NC-SA**  
Creative Commons Attribution-Noncommercial-Share Alike license. OER licensed CC-BY-NC-SA can be modified, but must be credit must be given to the author. Additionally, it may not be used commercially and must be shared in the same manner. 
