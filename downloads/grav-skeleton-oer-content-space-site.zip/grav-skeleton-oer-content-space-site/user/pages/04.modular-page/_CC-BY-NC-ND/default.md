---
title: CC-BY-NC-ND
---

**CC-BY-NC-ND**  
Creative Commons Attribution-Noncommerical-No derivatives. OER licensed CC-BY-NC-ND cannot be modified or used commercially. It may or may not be shared in the same manner and credit must be given to the author.
