---
title: 'Standard Page'
---

A **standard page** is the most common type of page that you will create with Grav. By default a page is considered a standard page unless you tell Grav otherwise.
