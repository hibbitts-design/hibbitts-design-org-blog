# v1.0.4
## XX/XX/2017

1. [](#improved)
    * Updated setup guide text
    * Updated example blog pages
    * Fixed blog widgets display behaviour

# v1.0.3
## 05/19/2017

1. [](#improved)
    * Adjusted layout of Next and Previous blog post buttons

# v1.0.2
## 05/09/2017

1. [](#improved)
    * Blog article spacing improved for Helium theme
    * Mobile menu rendering improved for Helium theme
    * Fixed footer area for Helium theme

# v1.0.1
## 05/04/2017

1. [](#improved)
    * Changed default Gantry 5 mode to Production
    * Improved mobile menu rendering

# v1.0.0
## 05/03/2017

1. [](#new)
    * Added direct link to skeleton documentation on learn.hibbittsdesign.org
1. [](#improved)
    * Added automatic check for dynamically generated pages (i.e. Login, Search, etc.).

# v0.9.9
## 04/19/2017

1. [](#new)
    * Added direct link to skeleton documentation on learn.hibbittsdesign.org

# v0.9.8
## 04/01/2017

1. [](#bugfix)
    * Corrected the page titles for the left and right sidebar pages

# v0.9.7
## 03/31/2017

1. [](#new)
    * Added support for text logo

# v0.9.6
## 03/27/2017

1. [](#improved)
    * Automatic display of left and/or right sidebars once any content is in either sidebar folder markdown file

# v0.9.5
## 03/05/2017

1. [](#improved)
    * Updated included particles

# v0.9.4
## 02/27/2017

1. [](#new)
    * Added experimental OER Schema (oerschema.org) particle

# v0.9.3
## 02/23/2017

1. [](#improved)
    * Updated Home page content
    * Updated example site pages

# v0.9.2
## 02/05/2017

1. [](#new)
    * Added left sidebar and right sidebar layouts

1. [](#improved)
    * Updated example site pages

# v0.9.1
## 02/04/2017

1. [](#improved)
    * Updated information and links for inclusion on getgrav.org site
    * Updated Gantry 5 theme outlines
    * Updated example site pages

# v0.9.0
## 01/31/2017

1. [](#new)
    * ChangeLog started...
