#!/bin/sh
scss --watch scss:assets/css-compiled
