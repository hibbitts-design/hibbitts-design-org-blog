jQuery(document).ready(function() {

	var footer, pagespace;

    function doResponsive() {
		footer = jQuery("#g-footer").height();
		pagespace = jQuery("#g-page-surround").css('padding-bottom', footer);
    }

    doResponsive();

    jQuery(window).resize(function() {
        doResponsive();
    });
});
