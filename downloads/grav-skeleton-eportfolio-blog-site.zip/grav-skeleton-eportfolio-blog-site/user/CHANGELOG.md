# v0.9.4
## 03/31/2017

1. [](#improved)
    * Improved support for use of text logo

# v0.9.3
## 03/27/2017

1. [](#improved)
    * Automatic display of sidebar once any content is in 'Sidebar' markdown file

# v0.9.2
## 03/09/2017

1. [](#bugfix)
    * GitHub repository links in Blueprints fixed

# v0.9.1
## 03/09/2017

1. [](#improved)
    * Git service icon automatically based on repository URL

# v0.9.0
## 03/05/2017

1. [](#new)
    * ChangeLog started...
