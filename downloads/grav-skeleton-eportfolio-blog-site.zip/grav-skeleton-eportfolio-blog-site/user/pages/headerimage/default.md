---
title: HeaderImage
published: false
routable: false
---
File to be used for the header image above the menubar.
Sample header image attribution: https://www.flickr.com/photos/haoli/6480826009/
