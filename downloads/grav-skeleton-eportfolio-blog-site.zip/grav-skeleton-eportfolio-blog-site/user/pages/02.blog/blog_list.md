---
title: Blog
visible: true
content:
    items: '@self.children'
    leading: 0
    columns: 2
    limit: 10
    order:
        by: date
        dir: desc
    show_date: true
    pagination: true
    url_taxonomy_filters: true
child_type: blog_item
---
