---
title: Images
routable: false
---
Page folder to store site-wide images.
