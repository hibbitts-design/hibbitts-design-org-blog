---
title: 'Week 8 (Oct 25 - Oct 31)'
date: 10/25/2017
published: false
hide_from_post_list: true
header_image_credit: Matt Cottam, Flickr.com
header_image_creditlink: 'https://www.flickr.com/photos/mattcottam/6192507935/'
---

##### Your H5 Heading
Your _awesome_ summary goes here.

===

##### Your H5 Heading
Your even **more amazing** content goes here.
