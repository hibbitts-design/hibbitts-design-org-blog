---
title: 'Week 10 (Nov 8 - 14)'
date: 11/08/2017
published: false
hide_from_post_list: true
header_image_credit: Pat Armstrong, Flickr.com
header_image_creditlink: 'https://www.flickr.com/photos/poisontofu/4762082009/'
---

##### Your H5 Heading
Your _awesome_ summary goes here.

===

##### Your H5 Heading
Your even **more amazing** content goes here.
