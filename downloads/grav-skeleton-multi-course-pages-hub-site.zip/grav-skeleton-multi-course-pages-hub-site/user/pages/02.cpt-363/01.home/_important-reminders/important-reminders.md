---
title: 'Important Reminders'
published: true
---

** Important CPT-363 Reminders **  
[Assignment #1](https://canvas.sfu.ca/courses/25492/assignments/142519) (UX Topic Summary) is due via Canvas at 5:30pm Apr 5th.
