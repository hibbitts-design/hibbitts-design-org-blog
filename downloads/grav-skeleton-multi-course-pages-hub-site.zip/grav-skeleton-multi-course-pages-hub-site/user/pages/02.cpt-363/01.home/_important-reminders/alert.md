---
title: 'Important Reminders'
published: true
---

** Important Reminders **  
* [Usability inspection](https://canvas.sfu.ca/courses/36662/assignments/267545) peer reviews due Oct 17th.
