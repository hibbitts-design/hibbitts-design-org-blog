---
title: 'Week 7 (Oct 18 - Oct 24)'
date: 10/18/2017
published: false
hide_from_post_list: true
header_image_credit: Samuel Mann, Flickr.com
header_image_creditlink: 'https://www.flickr.com/photos/21218849@N03/6968244538/'
---

##### Your H5 Heading
Your _awesome_ summary goes here.

===

##### Your H5 Heading
Your even **more amazing** content goes here.
