---
title: 'Class Preparations'
published: true
---

### Jan 26th CPT-363 Class Preparations

##### Required Readings
[Persona Empathy Mapping](http://www.cooper.com/journal/2014/05/persona-empathy-mapping)

[Required Reading Quiz](https://canvas.sfu.ca/courses/25492/quizzes/34783?classes=btn,btn-primary)  

Weekly quizzes are due by 10:00am the day of class. After attending this class, [share your one-minute summary](https://canvas.sfu.ca/courses/25492/discussion_topics/440791) before midnight, January 26th.
