---
title: 'Week 2 (Sep 13 - 19)'
published: true
date: '13-09-2017 00:00'
header_image_credit: 'CannedTuna, Flickr.com'
header_image_creditlink: 'https://www.flickr.com/photos/cannedtuna/4853380320/'
---

##### Presented Slides
[The Process of UX Design](https://swipe.to/9967fp)  

===

##### Summaries and Questions  
[Sep 13th Class One-minute Summaries](https://canvas.sfu.ca/courses/36662/assignments/267537)

##### Presented Slides  
The Process of UX Design ([Download slides as PDF](#))
<div class="embed-responsive embed-responsive-16by9"><figure><iframe src="https://www.swipe.to/embed/9967fp" allowfullscreen></iframe></figure></div>

##### CMPT-363 UX Design Process/Toolkit
![CMPT-363 UX Design Process/Toolkit Diagram](/images/ux-design-process-v4.png)

##### Assignments
[Project Proposal](https://canvas.sfu.ca/courses/36662/assignments/267529)   

##### Handouts
[Product Reaction Cards](https://canvas.sfu.ca/courses/36662/files/folder/Handouts/Product%20Reaction%20Cards)  

##### Recommended Reading  
<a class="embedly-card" data-card-controls="0" data-card-align="left" href="https://medium.com/salesforce-ux/designing-digital-products-with-mental-models-45ac5c0a9dc2">Designing Digital Products with Mental Models</a>
<script async src="//cdn.embedly.com/widgets/platform.js" charset="UTF-8"></script>
