---
title: 'Week 9 (Nov 1 - 7)'
date: 11/01/2017
published: false
hide_from_post_list: true
header_image_credit: Blake Patterson, Flickr.com
header_image_creditlink: 'https://www.flickr.com/photos/blakespot/16230041026/'
---

##### Your H5 Heading
Your _awesome_ summary goes here.

===

##### Your H5 Heading
Your even **more amazing** content goes here.
