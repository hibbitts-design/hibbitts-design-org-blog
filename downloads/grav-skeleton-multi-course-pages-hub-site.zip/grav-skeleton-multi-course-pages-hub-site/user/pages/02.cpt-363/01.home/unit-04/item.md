---
title: 'Week 4 (Sep 27 - Oct 3)'
published: true
date: '27-09-2017 00:00'
header_image_credit: 'Rick Dolishny, Flickr.com'
header_image_creditlink: 'https://www.flickr.com/photos/rdolishny/2760207306/'
---

##### Presented Slides
[User Interface Inspections](https://swipe.to/9967fp)

===

##### Summaries and Questions  
[Sep 27th Class One-minute Summaries](https://canvas.sfu.ca/courses/36662/assignments/267535)

##### Presented Slides  
User Interface Inspections ([Download slides as PDF](#))
<div class="embed-responsive embed-responsive-16by9"><figure><iframe src="https://www.swipe.to/embed/9967fp" allowfullscreen></iframe></figure></div>

##### Supplemental Materials  
[plugin:youtube](https://www.youtube.com/watch?v=gSm6bOw-KcQ)

##### Assignments
[Usability Inspection (Peer Reviews Required for Grade)](https://canvas.sfu.ca/courses/36662/assignments/267545)   
[Usability Inspection Report Template](https://canvas.sfu.ca/courses/36662/files/folder/Handouts/Usability%20Inspection%20Report%20Template#)

##### Required Reading  
<a class="embedly-card" data-card-controls="0" data-card-align="left" href="https://www.uxmatters.com/mt/archives/2014/06/an-overview-of-expert-heuristic-evaluations.php">An Overview of Expert Heuristic Evaluations</a>
<script async src="//cdn.embedly.com/widgets/platform.js" charset="UTF-8"></script>
