---
title: Sidebar
routable: false
visible: false
---

##### Course Facilitators
Some Name  
<somename@somewhere.edu>   
Office hours Mon. 4:00-5:15pm  
Harbour Centre 2146  

Another Name  
<anothername@somewhere.edu>  

##### Canvas LMS
[Calendar](https://canvas.sfu.ca/calendar)  
[Assignments](https://canvas.sfu.ca/courses/36662/assignments)  
[Quizzes](https://canvas.sfu.ca/courses/36662/quizzes)  
[Class Discussions](https://canvas.sfu.ca/courses/36662/discussion_topics)  
[Grades](https://canvas.sfu.ca/grades)  
[Syllabus](https://canvas.sfu.ca/courses/36662/assignments/syllabus)

<a class="twitter-timeline" data-height="600" data-chrome="noscrollbar" href="https://twitter.com/hibbittsdesign/lists/cpt-363">Tweets from https://twitter.com/hibbittsdesign/lists/cpt-363</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
