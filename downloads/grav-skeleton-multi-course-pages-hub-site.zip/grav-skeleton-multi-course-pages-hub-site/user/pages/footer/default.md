---
title: Footer
routable: false
visible: false
---
Bootstrap Theme for [Grav](http://getgrav.org)  
Course companion template modifications by:  
[hibbittsdesign.org](http://hibbittsdesign.org)
