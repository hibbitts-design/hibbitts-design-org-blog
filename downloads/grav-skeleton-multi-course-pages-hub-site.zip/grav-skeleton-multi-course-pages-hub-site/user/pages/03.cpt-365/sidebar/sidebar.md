---
title: 'Sidebar'
published: false
routable: false
visible: false
---

##### Course Pages
[CPT 365 Home](/cpt-365/home)  
[CPT 365 Resources](/cpt-365/resources)  
[CPT 365 Syllabus](/cpt-363/syllabus)  

##### Course Facilitators
Some Name  
<somename@somewhere.edu>   
Office hours Mon. 4:00-5:15pm  
Harbour Centre 2146  

Another Name  
<anothername@somewhere.edu>  

##### Course Links
[Calendar](https://canvas.sfu.ca/calendar)  
[Assignments](https://canvas.sfu.ca/courses/25492/assignments)  
[Quizzes](https://canvas.sfu.ca/courses/25492/quizzes)  
[Class Discussions](https://canvas.sfu.ca/courses/25492/discussion_topics)  
[Grades](https://canvas.sfu.ca/grades)  
[Syllabus](/cpt-365/syllabus)
