---
title: 'Course Welcome'
date: '01-05-2017 00:00'
icon: users
continue_link: false
---

Welcome to the multi-device friendly course hub for CPT-365 Fall 2017. To help orientate yourself to the course, explore the [course syllabus](https://canvas.sfu.ca/courses/36662/assignments/syllabus).

Any required preparations before each class will be posted here by Friday of the previous week. Assigned weekly reading quizzes must be submitted before 10:00am the day of each class, and please bring a copy of your answers to class to help facilitate possible discussion.

Materials to be presented in class will usually be available in draft form beforehand.
