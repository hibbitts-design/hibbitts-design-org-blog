---
title: 'Week 5 (Oct 4 - 10)'
published: true
date: '04-10-2017 00:00'
header_image_credit: 'Nicholas Wang, Flickr.com'
header_image_creditlink: 'https://www.flickr.com/photos/cloneofsnake/13966760787/'
hide_from_post_list: true
---

##### Presented Slides
[User Research](https://www.swipe.to/1951fq)

===

##### Summaries and Questions  
[Oct 4th Class One-minute Summaries](https://canvas.sfu.ca/courses/36662/assignments/267534)

##### Presented Slides  
User Research ([Download slides as PDF](#))
<div class="embed-responsive embed-responsive-16by9"><figure><iframe src="https://www.swipe.to/embed/9967fp" allowfullscreen></iframe></figure></div>

##### Supplemental Materials  
[What People Are Really Doing Video](http://vimeo.com/album/169777/video/7099570)  
<div class="embed-responsive embed-responsive-16by9"><iframe src="https://player.vimeo.com/video/7099570" width="500" height="275" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>

##### Required Reading  
<a class="embedly-card" data-card-controls="0" data-card-align="left" href="http://www.smashingmagazine.com/2013/09/5-step-process-conducting-user-research/">A Five-Step Process For Conducting User Research</a>
<script async src="//cdn.embedly.com/widgets/platform.js" charset="UTF-8"></script>
