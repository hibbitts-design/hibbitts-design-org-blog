---
title: 'Week 6 (Oct 11 - Oct 17)'
published: true
date: '11-10-2017 00:00'
header_image_credit: 'K2_UX, Flickr.com'
header_image_creditlink: 'https://www.flickr.com/photos/k2_ux/8447614292/'
hide_from_post_list: true
---

##### Presented Slides
[Usability Inspection](https://www.swipe.to/1951fq)

===

##### Summaries and Questions  
[Oct 11th Class One-minute Summaries](https://canvas.sfu.ca/courses/36662/assignments/267533)

##### Presented Slides  
Usability Inspection ([Download slides as PDF](#))
<div class="embed-responsive embed-responsive-16by9"><figure><iframe src="https://www.swipe.to/embed/9967fp" allowfullscreen></iframe></figure></div>

##### Supplemental Materials  
[plugin:youtube](https://www.youtube.com/watch?v=QckIzHC99Xc)

##### Assignments
[Usability Inspection Peer Reviews](https://canvas.sfu.ca/courses/36662/)

##### Required Reading  
<a class="embedly-card" data-card-controls="0" data-card-align="left" href="http://www.uxbooth.com/articles/the-art-of-guerrilla-usability-testing/">The Art of Guerrilla Usability Testing</a>
<script async src="//cdn.embedly.com/widgets/platform.js" charset="UTF-8"></script>
