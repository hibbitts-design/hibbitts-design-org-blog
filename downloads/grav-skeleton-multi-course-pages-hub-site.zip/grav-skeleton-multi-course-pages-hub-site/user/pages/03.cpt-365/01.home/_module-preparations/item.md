---
title: 'Class Preparations'
published: true
---

### Oct 4th Class Preparations

##### Required Reading
[A Five-Step Process For Conducting User Research](http://www.smashingmagazine.com/2013/09/5-step-process-conducting-user-research/)

[Required Reading Quiz](https://canvas.sfu.ca/courses/36662/quizzes/65506?classes=btn,btn-primary)

##### Slides to be Discussed
[User Research](https://www.swipe.to/1951fq)

Did you attend this class? [Share your one-minute summary](https://canvas.sfu.ca/courses/36662/assignments/267534) before midnight, the day of class.
