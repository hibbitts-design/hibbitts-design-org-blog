---
title: 'Week 1 (Sep 6 - 12)'
published: true
date: '06-09-2017 00:00'
header_image_credit: 'Amar Dhari, Flickr.com'
header_image_creditlink: 'https://www.flickr.com/photos/13202489@N04/17656394823/'
continue_link: true
hide_git_sync_repo_link: false
hide_from_post_list: false
---

##### Presented Slides
[Course Overview](https://www.swipe.to/1951fq)  
[Introduction to UX Design](https://www.swipe.to/1951fq)  

===

##### Summaries and Questions  
[Sep 6th Class One-minute Summaries](https://canvas.sfu.ca/courses/36662/assignments/267528)

##### Presented Slides  
Introduction to UX ([Download slides as PDF](#))
<div class="embed-responsive embed-responsive-16by9"><figure><iframe src="https://www.swipe.to/embed/9967fp" allowfullscreen></iframe></figure></div>
<br>

Introduction to UX ([Download slides as PDF](#))
<div class="embed-responsive embed-responsive-16by9"><figure><iframe src="https://www.swipe.to/embed/9967fp" allowfullscreen></iframe></figure></div>
<br>

##### Assignments
Create [team project group](https://canvas.sfu.ca/courses/36662/users)

##### Handouts
[Course Overview](https://canvas.sfu.ca/courses/36662/files/folder/Handouts/Course%20Overview)  

##### Recommended Reading  
<a class="embedly-card" data-card-controls="0" data-card-align="left" href="https://www.nngroup.com/articles/usability-101-introduction-to-usability/">Usability 101: Introduction to Usability</a>
<script async src="//cdn.embedly.com/widgets/platform.js" charset="UTF-8"></script>
