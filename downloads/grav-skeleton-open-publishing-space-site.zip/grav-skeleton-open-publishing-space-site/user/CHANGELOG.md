# v0.9.2
## 08/30/2017

1. [](#new)
    * Added OER Schema plugin as skeleton dependency

# v0.9.1
## 08/22/2017

1. [](#improved)
    * Updated example pages
    * Updated included Antimatter Open Publishing theme

# v0.9.0
## 08/17/2017

1. [](#new)
    * ChangeLog started...
