# v1.0.0
## 10/06/2017

1. [](#new)
    * Added support for image alt text on blog post image headers
    * Added support for image captions on blog post image headers
    * Added page header option to hide posts from blog index

# v0.9.4
## 09/22/2017

1. [](#improved)
    * Improved global handling of 'chromeless' display mode for embedded pages (thanks Ricardo)
    * Changed default Admin Panel widgets to Maintenance, Statistics and Page Updates (to make Page Updates more immediately visible) and removed Content Padding

# v0.9.3
## 09/22/2017

1. [](#improved)
    * Updated included Antimatter Open Publishing theme

# v0.9.2
## 08/30/2017

1. [](#new)
    * Added OER Schema plugin as skeleton dependency
    * Added TNTSearch plugin as skeleton dependency

# v0.9.1
## 08/22/2017

1. [](#improved)
    * Updated example pages
    * Updated included Antimatter Open Publishing theme

# v0.9.0
## 08/17/2017

1. [](#new)
    * ChangeLog started...
