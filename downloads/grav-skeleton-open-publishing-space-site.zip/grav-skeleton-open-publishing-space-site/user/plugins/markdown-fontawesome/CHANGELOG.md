# v1.0.1
## 2016-04-27

1. [](#improved)
    * Better plugin description added

# v1.0.0
## 2016-04-23

1. [](#new)
    * ChangeLog started...
