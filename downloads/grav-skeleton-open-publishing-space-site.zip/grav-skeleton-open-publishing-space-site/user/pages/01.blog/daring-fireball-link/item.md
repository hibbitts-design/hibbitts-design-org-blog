---
title: 'Just Some Text Today'
date: '13:34 07/10/2017'
taxonomy:
    category:
        - blog
    tag:
        - journal
        - link
hide_git_sync_repo_link: false
continue_link: true
link: 'http://daringfireball.net'
---

The open publishing skeleton also supports **Daring Fireball** style link posts.  Simply add a link setting in your page header:

```
link: http://daringfireball.net
```

And your post title becomes a link directly to that link you specified. Easy peasy!
