---
title: Standard Page
---

This is an example **standard** page, where content from one single page is displayed.
