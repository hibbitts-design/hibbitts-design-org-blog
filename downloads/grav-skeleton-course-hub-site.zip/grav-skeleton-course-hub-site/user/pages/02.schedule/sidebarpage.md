---
title: 'Schedule'
published: true
---
#### [Week 1 (Jan 5th - 11th)](/home/week-01)
**What is usability and user experience design?**  
[UX Topic Summary Assignment](https://canvas.sfu.ca/courses/25492/assignments/142519) due Mar 29th, 5:30pm  
[Course Overview Slides](http://slides.com/paulhibbitts/cpt-363-slides-placeholder/)  
[Introduction to UX Design Slides](http://slides.com/paulhibbitts/cpt-363-slides-placeholder/)   

#### [Week 2 (Jan 12th - 18th)](/home/week-02)
**What does a holistic user experience design process look like?**  
[The Process of UX Design Slides](http://slides.com/paulhibbitts/cpt-363-slides-placeholder#/)  
[Usability 101: Introduction to Usability](https://www.nngroup.com/articles/usability-101-introduction-to-usability/)  

#### [Week 3 (Jan 19th - 25th)](/home/week-03)
**How to understand people's needs and behaviors?**  
[User Research Slides](http://slides.com/paulhibbitts/cpt-363-slides-placeholder/)  
[A Five-Step Process For Conducting User Research](http://www.smashingmagazine.com/2013/09/23/5-step-process-conducting-user-research/) required reading before class  

#### Week 4 (Jan 26th - Feb 1st)
**How to communicate people's needs and behaviors?**  
User Modeling and Stories of Usage Slides (not available yet)  
[Persona Empathy Mapping](http://www.cooper.com/journal/2014/05/persona-empathy-mapping) required reading before class  
