---
title: 'Sidebar'
published: false
routable: false
---

##### Course Facilitators
Some Name  
<somename@somewhere.edu>   
Office hours Mon. 4:00-5:15pm  
Harbour Centre 2146  

Another Name  
<anothername@somewhere.edu>  

##### Canvas LMS
[Calendar](https://canvas.sfu.ca/calendar)  
[Assignments](https://canvas.sfu.ca/courses/25492/assignments)  
[Quizzes](https://canvas.sfu.ca/courses/25492/quizzes)  
[Class Discussions](https://canvas.sfu.ca/courses/25492/discussion_topics)  
[Grades](https://canvas.sfu.ca/grades)  

##### Twitter
<a class="twitter-timeline" data-width="500" data-height="600" data-chrome="noscrollbar" href="https://twitter.com/hibbittsdesign/lists/cpt-363">A Twitter List by hibbittsdesign</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
