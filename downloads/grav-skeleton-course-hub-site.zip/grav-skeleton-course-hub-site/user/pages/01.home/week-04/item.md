---
title: 'Week 4 (Jan 26th - Feb 1st)'
date: 01/26/2017
published: false
---

<!--- Your weekly summary content goes below here -->

<!--- Your weekly summary content goes above here -->

===

<!--- Your weekly materials content goes below here -->
