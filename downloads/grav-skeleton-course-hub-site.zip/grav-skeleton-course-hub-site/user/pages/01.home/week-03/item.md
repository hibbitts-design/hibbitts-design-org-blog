---
title: 'Week 3 (Jan 19th - 25th)'
date: 01/19/2017
published: true
---

##### Summaries and Questions  
[Jan 19th Class One-minute Summaries](https://canvas.sfu.ca/courses/25492/discussion_topics/440792)

##### Presented Slides  
[User Research Slides](http://slides.com/paulhibbitts/cpt-363-slides-placeholder#/)  

===

##### Summaries and Questions  
[Jan 19th Class One-minute Summaries](https://canvas.sfu.ca/courses/25492/discussion_topics/440792)

##### Presented Slides  
User Research Slides ([HTML Slides](http://slides.com/paulhibbitts/cpt-363-slides-placeholder/) | [PDF Slides](http://1drv.ms/1PKX6bG))
<div class="embed-responsive embed-responsive-4by3"><iframe class="embed-responsive-item" src="//slides.com/paulhibbitts/cpt-363-slides-placeholder/embed?style=light" width="576" height="420" scrolling="no" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>

##### Supplemental Video  
[What People Are Really Doing Video](http://vimeo.com/album/169777/video/7099570)  
<div class="embed-responsive embed-responsive-4by3"><iframe class="embed-responsive-item" src="https://player.vimeo.com/video/7099570?title=0&byline=0&portrait=0" width="500" height="275" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>

##### Required Reading  
[A Five-Step Process For Conducting User Research](http://www.smashingmagazine.com/2013/09/23/5-step-process-conducting-user-research/)  
<a class="embedly-card" data-card-align="left" href="http://www.smashingmagazine.com/2013/09/23/5-step-process-conducting-user-research/">A Five-Step Process For Conducting User Research</a>
<script async src="//cdn.embedly.com/widgets/platform.js" charset="UTF-8"></script>
