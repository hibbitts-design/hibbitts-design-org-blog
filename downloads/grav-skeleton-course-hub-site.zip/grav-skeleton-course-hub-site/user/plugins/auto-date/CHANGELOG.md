# v1.0.2
##  05/29/2016

1. [](#bugfix)
    * Fixed links in blueprint

# v1.0.1
##  09/30/2016

1. [](#improved)
    * Fixed icon

# v1.0.0
##  09/30/2016

1. [](#new)
    * Initial Release
