$(document).ready(function(){
    $('a[rel="lightbox"]').{pluginName}({
        openSpeed: {openSpeed},
        closeSpeed: {closeSpeed},
        closeOnClick: '{closeOnClick}',
        closeOnEsc: '{closeOnEsc}',
        root: '{root}'
    });
});
