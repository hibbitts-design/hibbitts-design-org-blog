---
title: Forgot password

form:
    fields:
        - name: username
          type: text
          placeholder: PLUGIN_ADMIN.USERNAME
          autofocus: true
          validate:
            required: true
---
