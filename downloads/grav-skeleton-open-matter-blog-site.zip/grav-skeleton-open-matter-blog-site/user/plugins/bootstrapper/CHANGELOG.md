# v2.0.0
## 05/25/2018

1. [](#new)
    * Added support for Bootstrap **v4.1.1** (with Popper.js)

# v1.3.4
## 02/01/2017

1. [](#improved)
    * Updated to Bootstrap version **v3.3.7**

# v1.3.3
## 10/19/2016

1. [](#new)
    * Added german and romanian translation

# v1.3.2
## 03/21/2016

1. [](#bugfix)
    * Added minified version of JS/CSS too, left out in the last release

# v1.3.1
## 03/12/2016

1. [](#new)
    * Added French translations
1. [](#improved)
    * Updated to Bootstrap version **v3.3.6**

# v1.3.0
## 10/07/2015

1. [](#new)
    * Added support for official Bootstrap CDN
    * Added Russian translations
1. [](#improved)
    * Updated to Bootstrap version **v3.3.5**

# v1.2.0
## 09/18/2015

1. [](#improved)
    * Don't load stuff in admin

# v1.1.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.0.2
## 03/04/2015

1. [](#bugfix)
    * Fix for properly toggling loading of core JS

# v1.0.1
## 02/28/2015

1. [](#improved)
    * Updated blueprints

# v1.0.0
## 02/27/2015

1. [](#improved)
    * Updated to Bootstrap version **v3.3.2**

# v0.9
## 02/27/2015

1. [](#new)
    * ChangeLog started...
