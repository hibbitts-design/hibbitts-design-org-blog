---
title: 'Week 1 (Jan 5th - 11th)'
date: 01/05/2016
published: true
---

##### Summaries and Questions  
[Jan 5th Class One-minute Summaries](https://canvas.sfu.ca/courses/25492/discussion_topics/440794)

##### Presented Slides  
[Course Overview Slides](http://slides.com/paulhibbitts/cpt-363-slides-placeholder/)  
[Introduction to UX Design Slides](http://slides.com/paulhibbitts/cpt-363-slides-placeholder/)

===

##### Summaries and Questions  
[Jan 5th Class One-minute Summaries](https://canvas.sfu.ca/courses/25492/discussion_topics/440794)

##### Presented Slides  
Course Overview ([HTML Slides](http://slides.com/paulhibbitts/cpt-363-slides-placeholder/) | [PDF Slides](http://1drv.ms/1PKX6bG))  
<div class="embed-responsive embed-responsive-4by3"><iframe class="embed-responsive-item" src="//slides.com/paulhibbitts/cpt-363-slides-placeholder/embed?style=light" width="576" height="420" scrolling="no" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>

Introduction to UX ([HTML Slides](http://slides.com/paulhibbitts/cpt-363-slides-placeholder/) | [PDF Slides](http://1drv.ms/1PKX6bG))  
<div class="embed-responsive embed-responsive-4by3"><iframe class="embed-responsive-item" src="//slides.com/paulhibbitts/cpt-363-slides-placeholder/embed?style=light" width="576" height="420" scrolling="no" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>

##### Supplemental Slides  
[Interaction Design History](http://www.slideshare.net/mrettig/interaction-design-history)  

##### Assignments
[UX Topic Summary](https://canvas.sfu.ca/courses/25492/assignments/142519)  

##### Suggested Reading  
[Five Ways to Become a Better Team Player](http://www.smashingmagazine.com/2013/09/23/5-step-process-conducting-user-research/)  
<a class="embedly-card" data-card-align="left" href="http://www.forbes.com/sites/dorieclark/2012/03/28/five-ways-to-become-a-better-team-player/">Five Ways to Become a Better Team Player</a>
<script async src="//cdn.embedly.com/widgets/platform.js" charset="UTF-8"></script>
