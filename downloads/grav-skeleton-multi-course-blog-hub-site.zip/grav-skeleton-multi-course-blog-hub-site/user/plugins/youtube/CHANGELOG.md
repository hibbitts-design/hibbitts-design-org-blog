# v2.0.4
## 09/28/2017

1. [](#improved)
    * Always use HTTPS for YouTube [#21](https://github.com/getgrav/grav-plugin-youtube/pull/21)

# v2.0.3
## 12/23/2016

1. [](#bugfix)
    * Fixed a JavaScript issue [#16](https://github.com/getgrav/grav-plugin-youtube/pull/16)

# v2.0.2
## 05/23/2016

1. [](#improved)
    * Supports `youtu.be` based short links
1. [](#bugfix)
    * Fixed for invalid URL with YouTube editor buttons
    * Fixed editor button to work with Admin v1.1

# v2.0.1
## 11/24/2015

1. [](#bugfix)
    * Fixed issue with case sensitivity when including new `YoutubeTwigExtension`

# v2.0.0
## 11/23/2015

1. [](#new)
    * Added player parameters configuration values (@hctom)
    * Added various YouTube options (@hctom)
    * Reworked output to use overridable Twig template (@hctom)
    * Added hebe.json (@hctom)

# v1.1.0
## 10/07/2015

1. [](#new)
    * Added admin editor button

# v1.0.0
## 05/09/2015

1. [](#new)
    * ChangeLog started...
